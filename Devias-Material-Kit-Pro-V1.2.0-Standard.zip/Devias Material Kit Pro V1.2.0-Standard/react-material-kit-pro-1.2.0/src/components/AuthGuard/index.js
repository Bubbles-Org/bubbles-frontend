export { default } from './AuthGuard';
