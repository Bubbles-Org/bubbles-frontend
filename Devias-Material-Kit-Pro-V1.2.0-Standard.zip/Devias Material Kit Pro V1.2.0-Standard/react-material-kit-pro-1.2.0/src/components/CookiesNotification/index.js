export { default } from './CookiesNotification';
