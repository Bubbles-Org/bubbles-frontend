export { default } from './SearchBar';
