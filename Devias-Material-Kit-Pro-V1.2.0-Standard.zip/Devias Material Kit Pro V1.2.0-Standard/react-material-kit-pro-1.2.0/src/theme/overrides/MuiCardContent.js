export default {
  root: {
    padding: 24
  }
};
