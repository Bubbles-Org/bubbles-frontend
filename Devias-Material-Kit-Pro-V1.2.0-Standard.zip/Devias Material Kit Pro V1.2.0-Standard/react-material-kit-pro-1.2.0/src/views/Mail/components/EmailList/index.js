export { default } from './EmailList';
