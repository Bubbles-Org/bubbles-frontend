export { default } from './AboutAuthor';
